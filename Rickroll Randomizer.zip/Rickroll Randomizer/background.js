chrome.tabs.onCreated.addListener((tab) => {
  console.log("✅ 새 탭이 생성됨");

  const rickrollUrl = "https://www.youtube.com/watch?v=dQw4w9WgXcQ";
  const chance = 0.5;

  if (Math.random() < chance) {
    console.log("🎯 릭롤 발동!");
    chrome.tabs.update(tab.id, { url: rickrollUrl });
  } else {
    console.log("😢 이번엔 패스");
  }
});
